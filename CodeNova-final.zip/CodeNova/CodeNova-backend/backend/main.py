from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .database import init_db
from .auth.auth import router as auth_router
from .farmers.farmers import router as farmers_router
from .applications.applications import router as applications_router
from .claims.claims import router as claims_router


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Initialize database tables when the server starts
    init_db()
    yield


app = FastAPI(
    title="Balibima API",
    description="Crop Insurance Management System",
    version="1.0.0",
    lifespan=lifespan,
)


# Allow frontend applications to access the API
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",
        "http://127.0.0.1:5173",
        "http://localhost:5500",
        "http://127.0.0.1:5500",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# Register all API routes under /api
for r in (auth_router, farmers_router, applications_router, claims_router):
    app.include_router(r, prefix="/api")


@app.get("/")
def home():
    return {
        "message": "Balibima backend is running"
    }


@app.get("/health")
def health_check():
    return {
        "status": "healthy"
    }