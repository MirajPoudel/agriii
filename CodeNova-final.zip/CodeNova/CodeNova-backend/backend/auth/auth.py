"""Authentication: farmer registration and login (phone + password)."""
import sqlite3

from fastapi import APIRouter, HTTPException

from ..database import get_connection
from .schemas import LoginRequest, RegisterRequest
from .security import (
    create_token,
    hash_password,
    normalize_phone,
    verify_password,
)

router = APIRouter(prefix="/auth", tags=["Auth"])


@router.post("/register", status_code=201)
def register(data: RegisterRequest):
    phone = normalize_phone(data.phone)
    if not 7 <= len(phone) <= 15:
        raise HTTPException(
            status_code=422,
            detail="Enter a valid phone number",
        )

    try:
        with get_connection() as conn:
            cursor = conn.execute(
                """
                INSERT INTO farmers
                (full_name, phone, email, address, password_hash)
                VALUES (?, ?, ?, ?, ?)
                """,
                (
                    data.full_name,
                    phone,
                    data.email,
                    data.address,
                    hash_password(data.password),
                ),
            )

            row = conn.execute(
                "SELECT id, full_name, phone, email, address FROM farmers WHERE id = ?",
                (cursor.lastrowid,),
            ).fetchone()

        return {
            "message": "Farmer registered successfully. You can now log in.",
            "farmer": dict(row),
        }

    except sqlite3.IntegrityError:
        raise HTTPException(
            status_code=409,
            detail="This phone number is already registered",
        )


@router.post("/login")
def login(data: LoginRequest):
    phone = normalize_phone(data.phone)

    with get_connection() as conn:
        row = conn.execute(
            "SELECT * FROM farmers WHERE phone = ?",
            (phone,),
        ).fetchone()

    if row is None or not verify_password(
        data.password, row["password_hash"]
    ):
        raise HTTPException(
            status_code=401,
            detail="Invalid phone number or password",
        )

    farmer = {k: row[k] for k in row.keys() if k != "password_hash"}
    return {
        "message": "Login successful",
        "token": create_token(row["id"]),
        "farmer": farmer,
    }