from pydantic import BaseModel, Field
from typing import Optional


# Farmer registration
class RegisterRequest(BaseModel):
    full_name: str = Field(min_length=2, max_length=100)
    phone: str = Field(min_length=7, max_length=20)
    email: Optional[str] = None
    address: str = Field(min_length=2, max_length=200)
    password: str = Field(min_length=6, max_length=128)


# Farmer login (phone number + password)
class LoginRequest(BaseModel):
    phone: str = Field(min_length=7, max_length=20)
    password: str = Field(min_length=1, max_length=128)