import base64
import hashlib
import hmac
import os
import re
import secrets
import time
from pathlib import Path

_KEY_FILE = Path(__file__).resolve().parent / ".secret_key"
TOKEN_TTL = 60 * 60 * 24 * 7  # 7 days


def _secret() -> bytes:
    env = os.environ.get("BALIBIMA_SECRET")
    if env:
        return env.encode()
    if not _KEY_FILE.exists():
        _KEY_FILE.write_text(secrets.token_hex(32))
    return _KEY_FILE.read_text().encode()


def normalize_phone(phone: str) -> str:
    """Keep digits only; drop a leading Nepal country code (977)."""
    digits = re.sub(r"\D", "", phone)
    if digits.startswith("977") and len(digits) > 10:
        digits = digits[3:]
    return digits


def hash_password(password: str) -> str:
    salt = os.urandom(16)
    dk = hashlib.scrypt(password.encode(), salt=salt, n=2**14, r=8, p=1)
    return f"scrypt${salt.hex()}${dk.hex()}"


def verify_password(password: str, stored: str | None) -> bool:
    if not stored:
        return False
    try:
        _, salt_hex, dk_hex = stored.split("$")
        dk = hashlib.scrypt(
            password.encode(), salt=bytes.fromhex(salt_hex),
            n=2**14, r=8, p=1,
        )
        return hmac.compare_digest(dk.hex(), dk_hex)
    except Exception:
        return False


def create_token(farmer_id: int) -> str:
    payload = f"{farmer_id}.{int(time.time()) + TOKEN_TTL}"
    sig = hmac.new(_secret(), payload.encode(), hashlib.sha256).hexdigest()
    return base64.urlsafe_b64encode(f"{payload}.{sig}".encode()).decode()