"""Farmer profiles (password hash is never returned)."""
from fastapi import APIRouter, HTTPException

from ..database import get_connection

router = APIRouter(prefix="/farmers", tags=["Farmers"])


@router.get("")
def list_farmers():
    with get_connection() as conn:
        rows = conn.execute(
            "SELECT id, full_name, phone, email, address FROM farmers ORDER BY id DESC"
        ).fetchall()

    return {"farmers": [dict(row) for row in rows]}


@router.get("/{farmer_id}")
def get_farmer(farmer_id: int):
    with get_connection() as conn:
        row = conn.execute(
            "SELECT id, full_name, phone, email, address FROM farmers WHERE id = ?",
            (farmer_id,),
        ).fetchone()

    if row is None:
        raise HTTPException(
            status_code=404,
            detail="Farmer not found",
        )

    return dict(row)