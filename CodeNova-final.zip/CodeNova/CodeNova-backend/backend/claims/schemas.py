from pydantic import BaseModel, Field
from typing import Optional


# New claim
class ClaimRequest(BaseModel):
    application_id: int = Field(gt=0)
    damage_reason: str = Field(min_length=2, max_length=200)
    description: Optional[str] = Field(default=None, max_length=1000)
    damage_date: Optional[str] = None
    photo_url: Optional[str] = None