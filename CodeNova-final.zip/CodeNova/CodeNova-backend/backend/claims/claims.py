"""Crop damage claims."""
import sqlite3

from fastapi import APIRouter, HTTPException

from ..database import get_connection
from ..applications.schemas import ClaimStatus
from .schemas import ClaimRequest

router = APIRouter(prefix="/claims", tags=["Claims"])


@router.post("", status_code=201)
def create_claim(data: ClaimRequest):
    try:
        with get_connection() as conn:
            application = conn.execute(
                "SELECT id FROM applications WHERE id = ?",
                (data.application_id,),
            ).fetchone()

            if application is None:
                raise HTTPException(
                    status_code=404,
                    detail="Insurance application not found",
                )

            # Populate the old required description column too.
            cursor = conn.execute(
                """
                INSERT INTO claims
                (
                    application_id,
                    description,
                    status,
                    damage_reason,
                    damage_date,
                    photo_url
                )
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (
                    data.application_id,
                    data.description or data.damage_reason,
                    "under_review",
                    data.damage_reason,
                    data.damage_date,
                    data.photo_url,
                ),
            )

            row = conn.execute(
                "SELECT * FROM claims WHERE id = ?",
                (cursor.lastrowid,),
            ).fetchone()

        return {
            "message": "Claim submitted successfully",
            "claim": dict(row),
        }

    except HTTPException:
        raise

    except sqlite3.Error as e:
        print("DATABASE ERROR:", repr(e))
        raise HTTPException(
            status_code=500,
            detail=f"Database error: {e}",
        )


@router.get("")
def list_claims(farmer_id: int | None = None):
    sql = """
        SELECT claims.*, applications.farmer_id, applications.crop_name,
               farmers.full_name, farmers.phone
        FROM claims
        JOIN applications ON applications.id = claims.application_id
        JOIN farmers ON farmers.id = applications.farmer_id
    """
    params = ()
    if farmer_id is not None:
        sql += " WHERE applications.farmer_id = ?"
        params = (farmer_id,)
    sql += " ORDER BY claims.id DESC"

    with get_connection() as conn:
        rows = conn.execute(sql, params).fetchall()

    return {"claims": [dict(row) for row in rows]}


@router.get("/{claim_id}")
def get_claim(claim_id: int):
    with get_connection() as conn:
        row = conn.execute(
            "SELECT * FROM claims WHERE id = ?",
            (claim_id,),
        ).fetchone()

    if row is None:
        raise HTTPException(
            status_code=404,
            detail="Claim not found",
        )

    return dict(row)


@router.patch("/{claim_id}/status")
def update_claim_status(
    claim_id: int,
    data: ClaimStatus,
):
    with get_connection() as conn:
        cursor = conn.execute(
            """
            UPDATE claims
            SET status = ?
            WHERE id = ?
            """,
            (data.status, claim_id),
        )

        if cursor.rowcount == 0:
            raise HTTPException(
                status_code=404,
                detail="Claim not found",
            )

        row = conn.execute(
            "SELECT * FROM claims WHERE id = ?",
            (claim_id,),
        ).fetchone()

    return {
        "message": "Claim status updated",
        "claim": dict(row),
    }