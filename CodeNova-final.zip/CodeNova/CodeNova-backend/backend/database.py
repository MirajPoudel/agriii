import sqlite3
from pathlib import Path
from contextlib import contextmanager

DB_PATH = Path(__file__).resolve().parent / "balibima.db"


@contextmanager
def get_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")

    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def init_db():
    with get_connection() as conn:

        # 1. Farmers table
        conn.execute("""
            CREATE TABLE IF NOT EXISTS farmers (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                full_name TEXT NOT NULL,
                phone TEXT NOT NULL UNIQUE,
                email TEXT,
                address TEXT NOT NULL,
                password_hash TEXT
            )
        """)

        # Add password_hash to farmers tables created before login existed
        farmer_cols = {
            row["name"]
            for row in conn.execute("PRAGMA table_info(farmers)").fetchall()
        }
        if "password_hash" not in farmer_cols:
            conn.execute("ALTER TABLE farmers ADD COLUMN password_hash TEXT")

        # 2. Applications table for new databases
        conn.execute("""
            CREATE TABLE IF NOT EXISTS applications (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                farmer_id INTEGER NOT NULL,
                farmer_name TEXT,
                crop_name TEXT NOT NULL,
                land_area REAL NOT NULL CHECK (land_area > 0),
                address TEXT NOT NULL,
                planting_date TEXT,
                status TEXT NOT NULL DEFAULT 'pending'
                    CHECK (status IN ('pending', 'approved', 'rejected')),
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (farmer_id) REFERENCES farmers(id)
            )
        """)

        # 3. Check existing applications columns
        columns = {
            row["name"]
            for row in conn.execute(
                "PRAGMA table_info(applications)"
            ).fetchall()
        }

        # 4. Add missing columns to an existing table
        migrations = {
            "farmer_id": "INTEGER",
            "farmer_name": "TEXT",
            "crop_name": "TEXT",
            "land_area": "REAL",
            "address": "TEXT",
            "planting_date": "TEXT",
            "status": "TEXT NOT NULL DEFAULT 'pending'",
            "created_at": "TEXT",
            "area_unit": "TEXT",
            "harvest_date": "TEXT",
            "crop_value": "REAL",
            "notes": "TEXT",
        }

        for column_name, column_type in migrations.items():
            if column_name not in columns:
                conn.execute(
                    f"ALTER TABLE applications "
                    f"ADD COLUMN {column_name} {column_type}"
                )

        # Fill created_at for existing records
        conn.execute("""
            UPDATE applications
            SET created_at = CURRENT_TIMESTAMP
            WHERE created_at IS NULL
        """)

        # 5. Claims table
        conn.execute("""
            CREATE TABLE IF NOT EXISTS claims (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                application_id INTEGER NOT NULL,
                description TEXT,
                damage_reason TEXT NOT NULL,
                damage_date TEXT,
                photo_url TEXT,
                status TEXT NOT NULL DEFAULT 'pending'
                    CHECK (status IN ('pending', 'under_review', 'approved',
                                      'resolved', 'rejected')),
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (application_id)
                    REFERENCES applications(id)
            )
        """)