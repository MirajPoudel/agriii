from pydantic import BaseModel, Field
from typing import Optional, Literal


# New insurance application
class InsuranceApplication(BaseModel):
    farmer_id: int = Field(gt=0)
    crop_name: str = Field(min_length=2, max_length=100)
    land_area: float = Field(gt=0)
    address: str = Field(min_length=2, max_length=200)
    planting_date: Optional[str] = None
    area_unit: str = "Ropani"
    harvest_date: Optional[str] = None
    crop_value: float = Field(default=0, ge=0)
    notes: Optional[str] = None


# Application and claim status update
class ApplicationStatus(BaseModel):
    status: Literal["pending", "approved", "rejected"]


class ClaimStatus(BaseModel):
    status: Literal["pending", "under_review", "approved", "resolved", "rejected"]