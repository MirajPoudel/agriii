"""Insurance applications."""
import sqlite3

from fastapi import APIRouter, HTTPException

from ..database import get_connection
from .schemas import ApplicationStatus, InsuranceApplication

router = APIRouter(prefix="/applications", tags=["Applications"])


@router.post("", status_code=201)
def create_application(data: InsuranceApplication):
    try:
        with get_connection() as conn:
            farmer = conn.execute(
                "SELECT * FROM farmers WHERE id = ?",
                (data.farmer_id,),
            ).fetchone()

            if farmer is None:
                raise HTTPException(
                    status_code=404,
                    detail="Farmer not found. Register first.",
                )

            cursor = conn.execute(
                """
                INSERT INTO applications
                (
                    farmer_name,
                    farmer_id,
                    crop_name,
                    land_area,
                    address,
                    planting_date,
                    status,
                    area_unit,
                    harvest_date,
                    crop_value,
                    notes
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    farmer["full_name"],
                    data.farmer_id,
                    data.crop_name,
                    data.land_area,
                    data.address,
                    data.planting_date,
                    "pending",
                    data.area_unit,
                    data.harvest_date,
                    data.crop_value,
                    data.notes,
                ),
            )

            row = conn.execute(
                "SELECT * FROM applications WHERE id = ?",
                (cursor.lastrowid,),
            ).fetchone()

        return {
            "message": "Insurance application submitted successfully",
            "application": dict(row),
        }

    except HTTPException:
        raise

    except sqlite3.Error as e:
        print("DATABASE ERROR:", repr(e))
        raise HTTPException(
            status_code=500,
            detail=f"Database error: {e}",
        )


@router.get("")
def list_applications(farmer_id: int | None = None):
    sql = """
        SELECT applications.*, farmers.full_name, farmers.phone
        FROM applications
        JOIN farmers ON farmers.id = applications.farmer_id
    """
    params = ()
    if farmer_id is not None:
        sql += " WHERE applications.farmer_id = ?"
        params = (farmer_id,)
    sql += " ORDER BY applications.id DESC"

    with get_connection() as conn:
        rows = conn.execute(sql, params).fetchall()

    return {"applications": [dict(row) for row in rows]}


@router.get("/{application_id}")
def get_application(application_id: int):
    with get_connection() as conn:
        row = conn.execute(
            "SELECT * FROM applications WHERE id = ?",
            (application_id,),
        ).fetchone()

    if row is None:
        raise HTTPException(
            status_code=404,
            detail="Application not found",
        )

    return dict(row)


@router.patch("/{application_id}/status")
def update_application_status(
    application_id: int,
    data: ApplicationStatus,
):
    with get_connection() as conn:
        cursor = conn.execute(
            """
            UPDATE applications
            SET status = ?
            WHERE id = ?
            """,
            (data.status, application_id),
        )

        if cursor.rowcount == 0:
            raise HTTPException(
                status_code=404,
                detail="Application not found",
            )

        row = conn.execute(
            "SELECT * FROM applications WHERE id = ?",
            (application_id,),
        ).fetchone()

    return {
        "message": "Application status updated",
        "application": dict(row),
    }