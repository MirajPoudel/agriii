ECHO is on.
