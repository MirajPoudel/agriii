/**
 * Balibima - api.js
 * Talks to the FastAPI backend and converts backend rows
 * into the shapes the existing frontend pages already render.
 */

const API_BASE = 'http://127.0.0.1:8000/api';
const TOKEN_KEY = 'balibima_token';

/* ---------- status + id helpers ---------- */
const STATUS_UI = {
    pending: 'Pending',
    under_review: 'Under Review',
    approved: 'Approved',
    resolved: 'Resolved',
    rejected: 'Rejected'
};
const toUiStatus = (s) => STATUS_UI[s] || s;
const toApiStatus = (s) => String(s).toLowerCase().replace(/\s+/g, '_');

const pad = (n) => String(n).padStart(3, '0');
const appCode = (id) => `APP-${pad(id)}`;
const claimCode = (id) => `CLM-${pad(id)}`;
const rawId = (code) => parseInt(String(code).split('-').pop(), 10);

/* ---------- core request helper ---------- */
async function apiFetch(path, options = {}) {
    const headers = { 'Content-Type': 'application/json', ...(options.headers || {}) };
    const token = localStorage.getItem(TOKEN_KEY);
    if (token) headers.Authorization = `Bearer ${token}`;

    let res;
    try {
        res = await fetch(API_BASE + path, { ...options, headers });
    } catch (err) {
        throw new Error('Cannot reach the server. Is the backend running on port 8000?');
    }

    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
        let msg = data.detail;
        if (Array.isArray(msg)) msg = msg.map((e) => e.msg).join(', ');
        throw new Error(msg || `Request failed (${res.status})`);
    }
    return data;
}

/* ---------- mappers: backend row -> frontend object ---------- */
function mapFarmer(f) {
    return {
        id: f.id,
        name: f.full_name,
        phone: f.phone,
        email: f.email || '',
        location: f.address,
        role: 'farmer'
    };
}

function mapApplication(r) {
    const value = Number(r.crop_value) || 0;
    const gross = value * 0.05;
    return {
        id: appCode(r.id),
        farmerId: r.farmer_id,
        farmerName: escapeHtml(r.full_name || r.farmer_name || ''),
        phone: escapeHtml(r.phone || ''),
        location: escapeHtml(r.address || ''),
        crop: escapeHtml(r.crop_name || ''),
        area: String(r.land_area),
        areaUnit: r.area_unit || 'Ropani',
        plantingDate: r.planting_date || '',
        harvestDate: r.harvest_date || '',
        cropValue: value,
        grossPremium: gross,
        subsidy: gross * 0.8,
        farmerShare: gross * 0.2,
        notes: r.notes || '',
        status: toUiStatus(r.status),
        appliedAt: (r.created_at || '').slice(0, 10)
    };
}

function mapClaim(r) {
    return {
        id: claimCode(r.id),
        farmerName: escapeHtml(r.full_name || ''),
        phone: escapeHtml(r.phone || ''),
        applicationId: appCode(r.application_id),
        crop: escapeHtml(r.crop_name || ''),
        damageDate: r.damage_date || '',
        reason: escapeHtml(r.damage_reason || ''),
        description: r.description || '',
        photo: r.photo_url || '',
        status: toUiStatus(r.status),
        reportedAt: (r.created_at || '').slice(0, 10)
    };
}

/* ---------- public API ---------- */
const API = {
    // Auth
    register({ name, phone, email, location, password }) {
        return apiFetch('/auth/register', {
            method: 'POST',
            body: JSON.stringify({
                full_name: name,
                phone,
                email: email || null,
                address: location,
                password
            })
        });
    },

    async login(phone, password) {
        const data = await apiFetch('/auth/login', {
            method: 'POST',
            body: JSON.stringify({ phone, password })
        });
        localStorage.setItem(TOKEN_KEY, data.token);
        return mapFarmer(data.farmer);
    },

    // Applications
    async listApplications(farmerId) {
        const q = farmerId ? `?farmer_id=${encodeURIComponent(farmerId)}` : '';
        const data = await apiFetch('/applications' + q);
        return data.applications.map(mapApplication);
    },

    async createApplication(user, f) {
        const data = await apiFetch('/applications', {
            method: 'POST',
            body: JSON.stringify({
                farmer_id: user.id,
                crop_name: f.crop,
                land_area: Number(f.area),
                address: f.location,
                planting_date: f.plantingDate || null,
                area_unit: f.areaUnit || 'Ropani',
                harvest_date: f.harvestDate || null,
                crop_value: Number(f.cropValue) || 0,
                notes: f.notes || null
            })
        });
        return appCode(data.application.id);
    },

    setApplicationStatus(code, uiStatus) {
        return apiFetch(`/applications/${rawId(code)}/status`, {
            method: 'PATCH',
            body: JSON.stringify({ status: toApiStatus(uiStatus) })
        });
    },

    // Claims
    async listClaims(farmerId) {
        const q = farmerId ? `?farmer_id=${encodeURIComponent(farmerId)}` : '';
        const data = await apiFetch('/claims' + q);
        return data.claims.map(mapClaim);
    },

    async createClaim(f) {
        const data = await apiFetch('/claims', {
            method: 'POST',
            body: JSON.stringify({
                application_id: rawId(f.applicationId),
                damage_reason: f.reason,
                description: f.description || null,
                damage_date: f.damageDate || null,
                photo_url: f.photo || null
            })
        });
        return claimCode(data.claim.id);
    },

    setClaimStatus(code, uiStatus) {
        return apiFetch(`/claims/${rawId(code)}/status`, {
            method: 'PATCH',
            body: JSON.stringify({ status: toApiStatus(uiStatus) })
        });
    }
};
