/**
 * Balibima - Agriculture & Food System Crop Insurance Prototype
 * app.js - Application State, Authentication, Storage & Page Controllers
 */

// Storage Keys
const STORAGE_KEYS = {
    USERS: 'balibima_users',
    CURRENT_USER: 'balibima_current_user',
    APPLICATIONS: 'balibima_applications',
    CLAIMS: 'balibima_claims'
};

// Seed Data for initial demo experience
const DEFAULT_FARMER = {
    id: 'USR-101',
    name: 'Ram Bahadur Thapa',
    phone: '9841234567',
    email: 'ram.farmer@gmail.com',
    location: 'Chitwan, Bharatpur-11',
    password: 'password123',
    role: 'farmer'
};

const DEFAULT_ADMIN = {
    id: 'ADMIN-01',
    name: 'Agriculture Insurance Officer',
    phone: 'admin',
    email: 'officer@balibima.gov.np',
    location: 'Department of Agriculture, Bagmati',
    password: 'admin123',
    role: 'admin'
};

const DEFAULT_APPLICATIONS = [
    {
        id: 'APP-2026-001',
        farmerName: 'Ram Bahadur Thapa',
        phone: '9841234567',
        location: 'Chitwan, Bharatpur-11',
        crop: 'Rice / Paddy',
        area: '4',
        areaUnit: 'Ropani',
        plantingDate: '2026-06-15',
        harvestDate: '2026-11-20',
        cropValue: 180000,
        grossPremium: 9000,
        subsidy: 7200,
        farmerShare: 1800,
        notes: 'Basmati fine paddy variety, irrigated land.',
        status: 'Approved',
        appliedAt: '2026-06-16'
    },
    {
        id: 'APP-2026-002',
        farmerName: 'Ram Bahadur Thapa',
        phone: '9841234567',
        location: 'Chitwan, Bharatpur-11',
        crop: 'Maize',
        area: '2.5',
        areaUnit: 'Ropani',
        plantingDate: '2026-08-10',
        harvestDate: '2026-12-15',
        cropValue: 95000,
        grossPremium: 4750,
        subsidy: 3800,
        farmerShare: 950,
        notes: 'Hybrid Rampur Composite Maize.',
        status: 'Pending',
        appliedAt: '2026-08-12'
    },
    {
        id: 'APP-2026-003',
        farmerName: 'Sita Kumari Adhikari',
        phone: '9801122334',
        location: 'Morang, Biratnagar',
        crop: 'Wheat',
        area: '10',
        areaUnit: 'Katha',
        plantingDate: '2026-10-01',
        harvestDate: '2027-03-20',
        cropValue: 140000,
        grossPremium: 7000,
        subsidy: 5600,
        farmerShare: 1400,
        notes: 'NL-971 variety wheat crop.',
        status: 'Approved',
        appliedAt: '2026-10-02'
    }
];

const DEFAULT_CLAIMS = [
    {
        id: 'CLM-2026-001',
        farmerName: 'Ram Bahadur Thapa',
        phone: '9841234567',
        applicationId: 'APP-2026-001',
        crop: 'Rice / Paddy',
        damageDate: '2026-09-28',
        reason: 'Flood / Waterlogging',
        description: 'Flash flood overflowed local irrigation canal after 48h torrential rain, submerging 3 ropani of paddy crop for 4 consecutive days.',
        photo: '',
        status: 'Under Review',
        reportedAt: '2026-09-29'
    }
];

// Helper: Local Storage Get/Set
function getStoredData(key, fallback = []) {
    try {
        const item = localStorage.getItem(key);
        return item ? JSON.parse(item) : fallback;
    } catch (e) {
        console.error('Storage parse error for', key, e);
        return fallback;
    }
}

function setStoredData(key, value) {
    try {
        localStorage.setItem(key, JSON.stringify(value));
    } catch (e) {
        console.error('Storage write error for', key, e);
    }
}

// Initialize seed data if not present
function initializeData() {
    if (!localStorage.getItem(STORAGE_KEYS.USERS)) {
        setStoredData(STORAGE_KEYS.USERS, [DEFAULT_FARMER, DEFAULT_ADMIN]);
    }
    if (!localStorage.getItem(STORAGE_KEYS.APPLICATIONS)) {
        setStoredData(STORAGE_KEYS.APPLICATIONS, DEFAULT_APPLICATIONS);
    }
    if (!localStorage.getItem(STORAGE_KEYS.CLAIMS)) {
        setStoredData(STORAGE_KEYS.CLAIMS, DEFAULT_CLAIMS);
    }
}

// User Session Management
function getCurrentUser() {
    return getStoredData(STORAGE_KEYS.CURRENT_USER, null);
}

function setCurrentUser(user) {
    if (user) {
        setStoredData(STORAGE_KEYS.CURRENT_USER, user);
    } else {
        localStorage.removeItem(STORAGE_KEYS.CURRENT_USER);
    }
}

function logout() {
    localStorage.removeItem(STORAGE_KEYS.CURRENT_USER);
    localStorage.removeItem('balibima_token');
    window.location.href = 'login.html';
}

// Quick Demo autofill helper on login page
function fillDemo(role) {
    const phoneInput = document.querySelector('input[name="phone"]');
    const passInput = document.querySelector('input[name="password"]');
    if (!phoneInput || !passInput) return;

    if (role === 'admin') {
        phoneInput.value = 'admin';
        passInput.value = 'admin123';
    } else {
        phoneInput.value = '9841234567';
        passInput.value = 'password123';
    }
}

// Format Currency
function formatNPR(num) {
    const n = Number(num) || 0;
    return 'NPR ' + n.toLocaleString('en-IN');
}

// Update Top Navigation Bar dynamically based on login state
function updateHeaderNav() {
    const user = getCurrentUser();
    const navLoginLink = document.getElementById('navLoginLink');
    const headerAuthBtn = document.getElementById('headerAuthBtn');
    const headerUserName = document.getElementById('headerUserName');

    if (user) {
        const userIcon = user.role === 'admin'
            ? `<svg class="icon icon-xs" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>`
            : `<svg class="icon icon-xs" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>`;

        if (headerUserName) {
            headerUserName.innerHTML = `${userIcon} <span>${escapeHtml(user.name || 'User')}</span>`;
        }

        if (headerAuthBtn) {
            headerAuthBtn.innerHTML = `
                <div class="user-action-group">
                    <span class="user-pill">${userIcon} ${user.role === 'admin' ? 'Admin' : escapeHtml(user.name.split(' ')[0])}</span>
                    <a class="btn sm" href="${user.role === 'admin' ? 'admin.html' : 'dashboard.html'}">Dashboard</a>
                    <button class="btn secondary sm" onclick="logout()">Logout</button>
                </div>
            `;
        }

        if (navLoginLink) {
            navLoginLink.textContent = user.role === 'admin' ? 'Admin Panel' : 'Dashboard';
            navLoginLink.href = user.role === 'admin' ? 'admin.html' : 'dashboard.html';
        }
    }
}

/* =========================================================
   PAGE CONTROLLERS
   ========================================================= */

// 0. HOME PAGE CONTROLLER
function initHomePage() {
    const homeCrop = document.getElementById('homeCrop');
    const homeValue = document.getElementById('homeValue');
    const homeArea = document.getElementById('homeArea');
    const homeAreaUnit = document.getElementById('homeAreaUnit');
    const resSum = document.getElementById('resSum');
    const resGross = document.getElementById('resGross');
    const resSubsidy = document.getElementById('resSubsidy');
    const resFarmer = document.getElementById('resFarmer');
    const homeApplyBtn = document.getElementById('homeApplyBtn');

    function updateHomeCalc() {
        if (!homeValue) return;
        const val = Math.max(0, Number(homeValue.value) || 0);
        const gross = val * 0.05;
        const subsidy = gross * 0.80;
        const farmer = gross * 0.20;

        if (resSum) resSum.textContent = formatNPR(val);
        if (resGross) resGross.textContent = formatNPR(gross);
        if (resSubsidy) resSubsidy.textContent = '- ' + formatNPR(subsidy);
        if (resFarmer) resFarmer.textContent = formatNPR(farmer);

        if (homeApplyBtn) {
            const crop = homeCrop ? homeCrop.value : '';
            const area = homeArea ? homeArea.value : '';
            const unit = homeAreaUnit ? homeAreaUnit.value : 'Ropani';
            homeApplyBtn.href = `apply.html?crop=${encodeURIComponent(crop)}&val=${val}&area=${area}&unit=${encodeURIComponent(unit)}`;
        }
    }

    if (homeValue) {
        homeValue.addEventListener('input', updateHomeCalc);
        if (homeCrop) homeCrop.addEventListener('change', updateHomeCalc);
        if (homeArea) homeArea.addEventListener('input', updateHomeCalc);
        if (homeAreaUnit) homeAreaUnit.addEventListener('change', updateHomeCalc);
        updateHomeCalc();
    }

    // FAQ Accordion toggles
    const faqQuestions = document.querySelectorAll('.faq-question');
    faqQuestions.forEach(btn => {
        btn.addEventListener('click', function () {
            const item = this.closest('.faq-item');
            if (item) {
                const isCurrentlyActive = item.classList.contains('active');
                document.querySelectorAll('.faq-item').forEach(i => i.classList.remove('active'));
                if (!isCurrentlyActive) {
                    item.classList.add('active');
                }
            }
        });
    });
}

// 1. LOGIN PAGE CONTROLLER
function initLoginPage() {
    const loginForm = document.getElementById('loginForm');
    if (!loginForm) return;

    const messageEl = document.getElementById('loginMessage');

    loginForm.addEventListener('submit', async function (e) {
        e.preventDefault();
        messageEl.className = '';
        messageEl.textContent = '';

        const formData = new FormData(loginForm);
        const phone = (formData.get('phone') || '').trim();
        const password = (formData.get('password') || '').trim();

        if (!phone || !password) {
            showMessage(messageEl, 'Please enter both phone number and password.', 'error');
            return;
        }

        // The backend has no admin accounts yet, so admin stays a local demo login
        if (phone === 'admin' && password === 'admin123') {
            setCurrentUser(DEFAULT_ADMIN);
            showMessage(messageEl, 'Login successful! Redirecting to Admin Panel...', 'success');
            setTimeout(() => { window.location.href = 'admin.html'; }, 700);
            return;
        }

        try {
            const user = await API.login(phone, password);
            setCurrentUser(user);
            showMessage(messageEl, `Welcome back, ${user.name}! Redirecting...`, 'success');
            setTimeout(() => { window.location.href = 'dashboard.html'; }, 700);
        } catch (err) {
            showMessage(messageEl, err.message, 'error');
        }
    });
}

// 2. REGISTER PAGE CONTROLLER
function initRegisterPage() {
    const registerForm = document.getElementById('registerForm');
    if (!registerForm) return;

    const messageEl = document.getElementById('registerMessage');

    registerForm.addEventListener('submit', async function (e) {
        e.preventDefault();
        messageEl.className = '';
        messageEl.textContent = '';

        const formData = new FormData(registerForm);
        const name = (formData.get('name') || '').trim();
        const phone = (formData.get('phone') || '').trim();
        const email = (formData.get('email') || '').trim();
        const location = (formData.get('location') || '').trim();
        const password = formData.get('password') || '';
        const confirmPassword = formData.get('confirmPassword') || '';

        if (password.length < 6) {
            showMessage(messageEl, 'Password must be at least 6 characters long.', 'error');
            return;
        }
        if (password !== confirmPassword) {
            showMessage(messageEl, 'Passwords do not match. Please verify.', 'error');
            return;
        }

        try {
            await API.register({ name, phone, email, location, password });
            const user = await API.login(phone, password);   // register does not return a token
            setCurrentUser(user);
            showMessage(messageEl, 'Account created successfully! Redirecting to your dashboard...', 'success');
            setTimeout(() => { window.location.href = 'dashboard.html'; }, 900);
        } catch (err) {
            showMessage(messageEl, err.message, 'error');
        }
    });
}

// 3. FARMER DASHBOARD CONTROLLER
function requireFarmer() {
    const user = getCurrentUser();
    if (!user || user.role !== 'farmer' || typeof user.id !== 'number') {
        window.location.href = 'login.html';
        return null;
    }
    return user;
}

function initDashboardPage() {
    const welcomeName = document.getElementById('welcomeName');
    if (!welcomeName) return;

    const user = requireFarmer();
    if (!user) return;

    welcomeName.textContent = `Welcome, ${user.name}!`;
    const userLocationSub = document.getElementById('userLocationSub');
    if (userLocationSub && user.location) {
        userLocationSub.textContent = `Farm Location: ${user.location} | Phone: ${user.phone}`;
    }

    renderDashboardData(user);
}

async function renderDashboardData(user) {
    let userApps = [];
    let userClaims = [];
    try {
        [userApps, userClaims] = await Promise.all([
            API.listApplications(user.id),
            API.listClaims(user.id)
        ]);
    } catch (err) {
        showToast(err.message);
    }

    // Update Counter Numbers
    const appCount = document.getElementById('appCount');
    const pendingCount = document.getElementById('pendingCount');
    const claimCount = document.getElementById('claimCount');

    if (appCount) appCount.textContent = userApps.length;
    if (pendingCount) pendingCount.textContent = userApps.filter(a => (a.status || '').toLowerCase() === 'pending').length;
    if (claimCount) claimCount.textContent = userClaims.length;

    // Render Applications List Table
    const appsListContainer = document.getElementById('applicationsList');
    if (appsListContainer) {
        if (userApps.length === 0) {
            appsListContainer.innerHTML = `
                <div class="empty">
                    <p>You haven't submitted any crop insurance applications yet.</p>
                    <a class="btn sm" href="apply.html" style="margin-top:10px;">Apply for Insurance Now</a>
                </div>
            `;
        } else {
            let html = `
                <table>
                    <thead>
                        <tr>
                            <th>Policy ID</th>
                            <th>Crop</th>
                            <th>Land Area</th>
                            <th>Insured Value</th>
                            <th>Farmer Premium</th>
                            <th>Govt Subsidy</th>
                            <th>Status</th>
                            <th>Applied Date</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
            `;

            userApps.forEach(app => {
                const statusClass = (app.status || 'Pending').toLowerCase().replace(/\s+/g, '-');
                html += `
                    <tr>
                        <td><b>${app.id}</b></td>
                        <td>${app.crop}</td>
                        <td>${app.area} ${app.areaUnit || 'Ropani'}</td>
                        <td>${formatNPR(app.cropValue)}</td>
                        <td><b style="color:var(--dark-green);">${formatNPR(app.farmerShare || (app.cropValue * 0.05 * 0.20))}</b></td>
                        <td><small style="color:var(--green);">${formatNPR(app.subsidy || (app.cropValue * 0.05 * 0.80))} (80%)</small></td>
                        <td><span class="status ${statusClass}">${app.status || 'Pending'}</span></td>
                        <td>${app.appliedAt || 'Recent'}</td>
                        <td>
                            <a class="btn secondary sm" href="claim.html?appId=${app.id}" title="Report damage for this policy">Report Damage</a>
                        </td>
                    </tr>
                `;
            });

            html += `</tbody></table>`;
            appsListContainer.innerHTML = html;
        }
    }

    // Render Claims List Table
    const claimsListContainer = document.getElementById('claimsList');
    if (claimsListContainer) {
        if (userClaims.length === 0) {
            claimsListContainer.innerHTML = `
                <div class="empty">
                    <p>No damage claims reported. Your crops are safe!</p>
                </div>
            `;
        } else {
            let html = `
                <table>
                    <thead>
                        <tr>
                            <th>Claim ID</th>
                            <th>Policy ID</th>
                            <th>Crop</th>
                            <th>Damage Date</th>
                            <th>Damage Cause</th>
                            <th>Description</th>
                            <th>Status</th>
                            <th>Reported Date</th>
                        </tr>
                    </thead>
                    <tbody>
            `;

            userClaims.forEach(claim => {
                const statusClass = (claim.status || 'Pending').toLowerCase().replace(/\s+/g, '-');
                html += `
                    <tr>
                        <td><b>${claim.id}</b></td>
                        <td>${claim.applicationId || 'N/A'}</td>
                        <td>${claim.crop}</td>
                        <td>${claim.damageDate}</td>
                        <td>${claim.reason}</td>
                        <td><span title="${escapeHtml(claim.description)}">${escapeHtml(claim.description).slice(0, 50)}${claim.description.length > 50 ? '...' : ''}</span></td>
                        <td><span class="status ${statusClass}">${claim.status || 'Pending'}</span></td>
                        <td>${claim.reportedAt || 'Recent'}</td>
                    </tr>
                `;
            });

            html += `</tbody></table>`;
            claimsListContainer.innerHTML = html;
        }
    }
}

// 4. APPLY FOR INSURANCE CONTROLLER
function initApplyPage() {
    const applicationForm = document.getElementById('applicationForm');
    if (!applicationForm) return;

    const user = requireFarmer();
    if (!user) return;

    // Prefill user information
    const farmerNameInput = document.getElementById('farmerName');
    const farmerPhoneInput = document.getElementById('farmerPhone');
    const farmerLocationInput = document.getElementById('farmerLocation');

    if (farmerNameInput && !farmerNameInput.value) farmerNameInput.value = user.name || '';
    if (farmerPhoneInput && !farmerPhoneInput.value) farmerPhoneInput.value = user.phone || '';
    if (farmerLocationInput && !farmerLocationInput.value) farmerLocationInput.value = user.location || '';

    // Live Premium & Subsidy Calculator
    const cropValueInput = document.getElementById('cropValueInput') || document.querySelector('input[name="cropValue"]');
    const estSumInsured = document.getElementById('estSumInsured');
    const estGrossPremium = document.getElementById('estGrossPremium');
    const estGovtSubsidy = document.getElementById('estGovtSubsidy');
    const estFarmerPremium = document.getElementById('estFarmerPremium');

    // Prefill from Home Calculator URL query params if present
    const urlParams = new URLSearchParams(window.location.search);
    const paramCrop = urlParams.get('crop');
    const paramVal = urlParams.get('val');
    const paramArea = urlParams.get('area');
    const paramUnit = urlParams.get('unit');

    const cropSelect = document.querySelector('select[name="crop"]');
    const areaInput = document.querySelector('input[name="area"]');
    const areaUnitSelect = document.querySelector('select[name="areaUnit"]');

    if (paramCrop && cropSelect) cropSelect.value = paramCrop;
    if (paramVal && cropValueInput) cropValueInput.value = paramVal;
    if (paramArea && areaInput) areaInput.value = paramArea;
    if (paramUnit && areaUnitSelect) areaUnitSelect.value = paramUnit;

    function calculateSubsidy() {
        const value = Number(cropValueInput.value) || 0;
        const grossPremium = value * 0.05; // 5% standard crop premium
        const subsidy = grossPremium * 0.80; // Nepal Govt 80% subsidy
        const farmerShare = grossPremium * 0.20; // 20% farmer share

        if (estSumInsured) estSumInsured.textContent = formatNPR(value);
        if (estGrossPremium) estGrossPremium.textContent = formatNPR(grossPremium);
        if (estGovtSubsidy) estGovtSubsidy.textContent = '- ' + formatNPR(subsidy) + ' (80%)';
        if (estFarmerPremium) estFarmerPremium.textContent = formatNPR(farmerShare) + ' (20%)';
    }

    if (cropValueInput) {
        cropValueInput.addEventListener('input', calculateSubsidy);
        calculateSubsidy();
    }

    // Handle form submit
    const messageEl = document.getElementById('applicationMessage');

    applicationForm.addEventListener('submit', async function (e) {
        e.preventDefault();
        messageEl.className = 'full';
        messageEl.textContent = '';

        const formData = new FormData(applicationForm);
        const fields = {
            location: formData.get('location'),
            crop: formData.get('crop'),
            area: formData.get('area'),
            areaUnit: formData.get('areaUnit') || 'Ropani',
            plantingDate: formData.get('plantingDate'),
            harvestDate: formData.get('harvestDate') || '',
            cropValue: Number(formData.get('cropValue')) || 0,
            notes: formData.get('notes') || ''
        };

        try {
            const code = await API.createApplication(user, fields);
            showMessage(messageEl, `Application submitted successfully with Policy ID #${code}! Redirecting to Dashboard...`, 'success');
            setTimeout(() => { window.location.href = 'dashboard.html'; }, 1200);
        } catch (err) {
            showMessage(messageEl, err.message, 'error');
        }
    });
}

// 5. CLAIM REPORTING CONTROLLER
let photoBase64 = '';

async function initClaimPage() {
    const claimForm = document.getElementById('claimForm');
    if (!claimForm) return;

    const user = requireFarmer();
    if (!user) return;

    // Prefill farmer info
    const claimFarmerName = document.getElementById('claimFarmerName');
    const claimPhone = document.getElementById('claimPhone');
    if (claimFarmerName && !claimFarmerName.value) claimFarmerName.value = user.name || '';
    if (claimPhone && !claimPhone.value) claimPhone.value = user.phone || '';

    // Populate the policy dropdown from the backend
    const claimAppSelect = document.getElementById('claimApplication');
    const claimCropSelect = document.getElementById('claimCrop') || document.querySelector('select[name="crop"]');
    const messageEl = document.getElementById('claimMessage');

    let userApps = [];
    try {
        userApps = await API.listApplications(user.id);
    } catch (err) {
        showMessage(messageEl, err.message, 'error');
    }

    if (claimAppSelect) {
        userApps.forEach(app => {
            const opt = document.createElement('option');
            opt.value = app.id;
            opt.textContent = `${app.id} - ${app.crop} (${app.area} ${app.areaUnit || 'Ropani'}) [${app.status}]`;
            claimAppSelect.appendChild(opt);
        });

        const preselectedAppId = new URLSearchParams(window.location.search).get('appId');
        if (preselectedAppId) {
            claimAppSelect.value = preselectedAppId;
            const matched = userApps.find(a => a.id === preselectedAppId);
            if (matched && claimCropSelect) claimCropSelect.value = matched.crop;
        }

        claimAppSelect.addEventListener('change', function () {
            const selectedApp = userApps.find(a => a.id === claimAppSelect.value);
            if (selectedApp && claimCropSelect) {
                for (let option of claimCropSelect.options) {
                    if (option.text.toLowerCase().includes(selectedApp.crop.toLowerCase()) ||
                        selectedApp.crop.toLowerCase().includes(option.text.toLowerCase())) {
                        claimCropSelect.value = option.value;
                        break;
                    }
                }
            }
        });
    }

    // Photo preview
    const photoInput = document.getElementById('claimPhotoInput') || document.querySelector('input[name="photo"]');
    const previewContainer = document.getElementById('photoPreviewContainer');
    const previewImg = document.getElementById('photoPreview');

    if (photoInput) {
        photoInput.addEventListener('change', function () {
            const file = photoInput.files[0];
            if (!file) return;
            if (file.size > 2 * 1024 * 1024) {
                showMessage(messageEl, 'Photo is too large. Please choose an image under 2 MB.', 'error');
                photoInput.value = '';
                return;
            }
            const reader = new FileReader();
            reader.onload = function (e) {
                photoBase64 = e.target.result;
                if (previewImg) previewImg.src = photoBase64;
                if (previewContainer) previewContainer.style.display = 'flex';
            };
            reader.readAsDataURL(file);
        });
    }

    // Submit claim
    claimForm.addEventListener('submit', async function (e) {
        e.preventDefault();
        messageEl.className = 'full';
        messageEl.textContent = '';

        const formData = new FormData(claimForm);
        const applicationId = formData.get('applicationId');
        if (!applicationId) {
            showMessage(messageEl, 'Please select the policy this claim is for.', 'error');
            return;
        }

        try {
            const code = await API.createClaim({
                applicationId,
                reason: formData.get('reason'),
                description: formData.get('description'),
                damageDate: formData.get('damageDate'),
                photo: photoBase64
            });
            showMessage(messageEl, `Crop damage reported successfully under Claim #${code}! Redirecting...`, 'success');
            setTimeout(() => { window.location.href = 'dashboard.html'; }, 1200);
        } catch (err) {
            showMessage(messageEl, err.message, 'error');
        }
    });
}

function clearPhotoPreview() {
    photoBase64 = '';
    const photoInput = document.getElementById('claimPhotoInput') || document.querySelector('input[name="photo"]');
    const previewContainer = document.getElementById('photoPreviewContainer');
    if (photoInput) photoInput.value = '';
    if (previewContainer) previewContainer.style.display = 'none';
}

// 6. ADMIN PANEL CONTROLLER
function initAdminPage() {
    const adminAppsContainer = document.getElementById('adminApplications');
    if (!adminAppsContainer) return;

    renderAdminPanel();
}

let adminApps = [];
let adminClaims = [];

async function renderAdminPanel() {
    try {
        [adminApps, adminClaims] = await Promise.all([
            API.listApplications(),
            API.listClaims()
        ]);
    } catch (err) {
        showToast(err.message);
    }

    const totalAppsEl = document.getElementById('adminTotalApps');
    const pendingAppsEl = document.getElementById('adminPendingApps');
    const totalClaimsEl = document.getElementById('adminTotalClaims');

    if (totalAppsEl) totalAppsEl.textContent = adminApps.length;
    if (pendingAppsEl) pendingAppsEl.textContent = adminApps.filter(a => (a.status || '').toLowerCase() === 'pending').length;
    if (totalClaimsEl) totalClaimsEl.textContent = adminClaims.length;

    renderAdminApplicationsTable(adminApps);
    renderAdminClaimsTable(adminClaims);
}

function renderAdminApplicationsTable(apps) {
    const container = document.getElementById('adminApplications');
    if (!container) return;

    const filterVal = document.getElementById('filterAppStatus')?.value || 'All';
    const filteredApps = (filterVal === 'All')
        ? apps
        : apps.filter(a => (a.status || 'Pending').toLowerCase() === filterVal.toLowerCase());

    if (filteredApps.length === 0) {
        container.innerHTML = `<p class="empty">No insurance applications found for filter "${filterVal}".</p>`;
        return;
    }

    let html = `
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Farmer Name</th>
                    <th>Phone</th>
                    <th>Location</th>
                    <th>Crop & Area</th>
                    <th>Insured Value</th>
                    <th>Govt Subsidy</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
    `;

    filteredApps.forEach(app => {
        const currentStatus = app.status || 'Pending';
        const statusClass = currentStatus.toLowerCase().replace(/\s+/g, '-');
        html += `
            <tr>
                <td><b>${app.id}</b></td>
                <td>${app.farmerName}</td>
                <td>${app.phone}</td>
                <td><small>${app.location}</small></td>
                <td><b>${app.crop}</b><br><small>${app.area} ${app.areaUnit || 'Ropani'}</small></td>
                <td>${formatNPR(app.cropValue)}</td>
                <td><span style="color:var(--green);">${formatNPR(app.subsidy || (app.cropValue * 0.04))}</span></td>
                <td><span class="status ${statusClass}" id="badge-app-${app.id}">${currentStatus}</span></td>
                <td>
                    <select class="admin-select" onchange="updateApplicationStatus('${app.id}', this.value)">
                        <option value="Pending" ${currentStatus === 'Pending' ? 'selected' : ''}>Pending</option>
                        <option value="Approved" ${currentStatus === 'Approved' ? 'selected' : ''}>Approved</option>
                        <option value="Rejected" ${currentStatus === 'Rejected' ? 'selected' : ''}>Rejected</option>
                    </select>
                </td>
            </tr>
        `;
    });

    html += `</tbody></table>`;
    container.innerHTML = html;
}

function renderAdminClaimsTable(claims) {
    const container = document.getElementById('adminClaims');
    if (!container) return;

    const filterVal = document.getElementById('filterClaimStatus')?.value || 'All';
    const filteredClaims = (filterVal === 'All')
        ? claims
        : claims.filter(c => (c.status || 'Pending').toLowerCase() === filterVal.toLowerCase());

    if (filteredClaims.length === 0) {
        container.innerHTML = `<p class="empty">No crop damage claims found for filter "${filterVal}".</p>`;
        return;
    }

    let html = `
        <table>
            <thead>
                <tr>
                    <th>Claim ID</th>
                    <th>Policy Ref</th>
                    <th>Farmer</th>
                    <th>Crop & Incident Date</th>
                    <th>Damage Reason</th>
                    <th>Description</th>
                    <th>Evidence</th>
                    <th>Status</th>
                    <th>Decision</th>
                </tr>
            </thead>
            <tbody>
    `;

    filteredClaims.forEach(claim => {
        const currentStatus = claim.status || 'Under Review';
        const statusClass = currentStatus.toLowerCase().replace(/\s+/g, '-');
        const photoHtml = claim.photo
            ? `<img src="${claim.photo}" class="claim-thumb" onclick="openPhotoModal('${claim.photo}', '${escapeHtml(claim.id)} - ${escapeHtml(claim.reason)}')" title="Click to enlarge">`
            : `<small style="color:var(--muted);">No photo</small>`;

        html += `
            <tr>
                <td><b>${claim.id}</b></td>
                <td>${claim.applicationId || 'N/A'}</td>
                <td><b>${claim.farmerName}</b><br><small>${claim.phone}</small></td>
                <td><b>${claim.crop}</b><br><small>${claim.damageDate}</small></td>
                <td><span style="color:#b91c1c; font-weight:600;">${claim.reason}</span></td>
                <td><small>${escapeHtml(claim.description)}</small></td>
                <td>${photoHtml}</td>
                <td><span class="status ${statusClass}" id="badge-clm-${claim.id}">${currentStatus}</span></td>
                <td>
                    <select class="admin-select" onchange="updateClaimStatus('${claim.id}', this.value)">
                        <option value="Pending" ${currentStatus === 'Pending' ? 'selected' : ''}>Pending</option>
                        <option value="Under Review" ${currentStatus === 'Under Review' ? 'selected' : ''}>Under Review</option>
                        <option value="Approved" ${currentStatus === 'Approved' ? 'selected' : ''}>Approved</option>
                        <option value="Resolved" ${currentStatus === 'Resolved' ? 'selected' : ''}>Resolved</option>
                        <option value="Rejected" ${currentStatus === 'Rejected' ? 'selected' : ''}>Rejected</option>
                    </select>
                </td>
            </tr>
        `;
    });

    html += `</tbody></table>`;
    container.innerHTML = html;
}

// Admin Action: Update Application Status
async function updateApplicationStatus(appId, newStatus) {
    try {
        await API.setApplicationStatus(appId, newStatus);
    } catch (err) {
        showToast(err.message);
        renderAdminPanel();   // put the dropdown back to the real value
        return;
    }
    const app = adminApps.find(a => a.id === appId);
    if (app) app.status = newStatus;

    const badge = document.getElementById(`badge-app-${appId}`);
    if (badge) {
        badge.textContent = newStatus;
        badge.className = `status ${newStatus.toLowerCase().replace(/\s+/g, '-')}`;
    }
    const pendingAppsEl = document.getElementById('adminPendingApps');
    if (pendingAppsEl) {
        pendingAppsEl.textContent = adminApps.filter(a => (a.status || '').toLowerCase() === 'pending').length;
    }
    showToast(`Policy ${appId} status updated to ${newStatus}`);
}

// Admin Action: Update Claim Status
async function updateClaimStatus(claimId, newStatus) {
    try {
        await API.setClaimStatus(claimId, newStatus);
    } catch (err) {
        showToast(err.message);
        renderAdminPanel();
        return;
    }
    const claim = adminClaims.find(c => c.id === claimId);
    if (claim) claim.status = newStatus;

    const badge = document.getElementById(`badge-clm-${claimId}`);
    if (badge) {
        badge.textContent = newStatus;
        badge.className = `status ${newStatus.toLowerCase().replace(/\s+/g, '-')}`;
    }
    showToast(`Claim ${claimId} status updated to ${newStatus}`);
}

// Filter functions for Admin (filter the data already loaded from the API)
function filterAdminApplications() { renderAdminApplicationsTable(adminApps); }
function filterAdminClaims() { renderAdminClaimsTable(adminClaims); }

// Demo reset no longer applies: data now lives in the database
function resetDemoData() {
    showToast('Data now lives in the backend database. Refreshing from server...');
    renderAdminPanel();
}

// Photo Modal Functions
function openPhotoModal(imgSrc, caption) {
    const modal = document.getElementById('photoModal');
    const modalImg = document.getElementById('modalImage');
    const modalCap = document.getElementById('modalCaption');
    if (!modal) return;
    if (modalImg) modalImg.src = imgSrc;
    if (modalCap) modalCap.textContent = caption || '';
    modal.style.display = 'flex';
}

function closePhotoModal(event) {
    const modal = document.getElementById('photoModal');
    if (!modal) return;
    if (!event || event.target === modal || event.target.classList.contains('modal-close')) {
        modal.style.display = 'none';
    }
}

// Toast notification helper
function showToast(message) {
    let toast = document.getElementById('appToast');
    if (!toast) {
        toast = document.createElement('div');
        toast.id = 'appToast';
        toast.className = 'toast-notification';
        document.body.appendChild(toast);
    }
    toast.textContent = message;
    toast.classList.add('show');
    setTimeout(() => {
        toast.classList.remove('show');
    }, 2500);
}

// Show alert message inside form
function showMessage(el, text, type) {
    if (!el) return;
    el.textContent = text;
    el.className = type === 'success' ? 'msg-success' : 'msg-error';
}

// Escape HTML utility
function escapeHtml(str) {
    if (!str) return '';
    return str
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
}

/* =========================================================
   INITIALIZATION ON DOM READY
   ========================================================= */
document.addEventListener('DOMContentLoaded', function () {
    updateHeaderNav();
    initHomePage();
    initLoginPage();
    initRegisterPage();
    initDashboardPage();
    initApplyPage();
    initClaimPage();
    initAdminPage();
});
