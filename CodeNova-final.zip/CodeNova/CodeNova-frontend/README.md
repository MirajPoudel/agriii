# 🌱 Balibima - Smart Agriculture Crop Insurance Platform

> **LICT Intra-College Hackathon 2026**  
> **Theme:** Agriculture & Food System  
> **Team:** CodeNova

---

## 📌 Overview
**Balibima** (बाली बीमा) is a modern, responsive digital crop insurance platform designed to empower farmers and streamline agricultural risk protection in Nepal. The application bridges the gap between smallholder farmers and agricultural insurance underwriters by digitizing:
1. **Farmer Registration & Profiles**
2. **Crop Insurance Application & Area Mapping**
3. **Automated Nepal Government Subsidy & Premium Calculation**
4. **Crop Damage Incident Reporting with Evidence Photos**
5. **Real-time Policy & Claim Adjudication for Insurance Officers**

---

## 🌾 Key Features

### 1. Farmer Portal
- **Simple Onboarding**: Quick sign-up and sign-in with phone number and district location.
- **Smart Subsidy Estimator**: Automatically calculates policy premiums based on standard agricultural rates:
  - **Gross Premium**: 5% of estimated crop value
  - **Government Subsidy**: 80% subsidized under Nepal's agricultural insurance scheme
  - **Farmer Payable**: Only 20% farmer contribution
- **Damage Reporting**: Fast, direct filing for losses resulting from floods, drought, hail, pests, or landslides, complete with photo evidence.
- **Status Tracking**: Visual progress indicators for submitted policies and claims (`Pending`, `Approved`, `Under Review`, `Resolved`, `Rejected`).

### 2. Admin / Insurance Underwriter Panel
- **Verification Dashboard**: High-level counters for total policies, pending applications, and reported claims.
- **Decision Workflow**: One-click status updates (`Pending` ➔ `Approved` / `Rejected`).
- **Claim Investigation**: Inspect claim details, linked policy numbers, farmer contact info, and enlarge photo evidence in a modal lightbox.
- **Demo State Reset**: Instantly restore seed data for quick hackathon judging demonstrations.

---

## 🚀 Demo Accounts

| Role | Username / Phone | Password | Destination |
| :--- | :--- | :--- | :--- |
| **Demo Farmer** | `9841234567` | `password123` | Farmer Dashboard (`dashboard.html`) |
| **Admin Officer** | `admin` | `admin123` | Admin Panel (`admin.html`) |

> 💡 *Tip: On the [Login Page](login.html), click the quick-fill buttons (`🌾 Farmer Demo` or `🛡️ Admin Demo`) to autofill credentials instantly!*

---

## 📁 Project Structure

```
CodeNova/
├── README.md               # Project documentation
└── frontend/
    ├── index.html          # Public landing page & service highlights
    ├── login.html          # Authentication with demo quick-switches
    ├── register.html       # Farmer account onboarding
    ├── dashboard.html      # Farmer management dashboard & counters
    ├── apply.html          # Insurance application & live subsidy calculator
    ├── claim.html          # Crop damage claim filing with photo upload
    ├── admin.html          # Underwriter review & claim adjudication panel
    ├── app.js              # State engine, LocalStorage persistence & controllers
    └── style.css           # Responsive design, theme variables & mobile styles
```

---

## 💻 How to Run Locally

Because Balibima is built with modern, dependency-free vanilla HTML5, CSS3, and JavaScript, it can be run directly:

### Option 1: Direct File Open
Simply double-click `frontend/index.html` in any web browser (Chrome, Edge, Safari, Firefox).

### Option 2: Local Python Server (Recommended)
Open your terminal inside the `CodeNova` directory and start a local web server:
```bash
cd CodeNova/frontend
python3 -m http.server 8000
```
Then visit: `http://localhost:8000`

---

## 📜 Technical Highlights
- **Zero-Dependency Architecture**: No external packages required; runs entirely in-browser.
- **Client-Side Persistence**: Employs `localStorage` to persist users, submitted applications, and damage reports across browser reloads.
- **Mobile First & Responsive**: CSS Grid & Flexbox layouts adapt seamlessly to mobile smartphones, tablets, and desktops.
- **Clean Semantic Code**: Accessible HTML tags, semantic forms, and modern ES6 JavaScript.

---

© 2026 Balibima | LICT Intra-College Hackathon 2026
