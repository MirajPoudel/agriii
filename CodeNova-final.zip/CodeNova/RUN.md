# CodeNova (Balibima) - connected frontend + backend

## 1. Backend (terminal 1)
cd CodeNova-backend
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
uvicorn backend.main:app --reload --port 8000
(API docs: http://127.0.0.1:8000/docs)

## 2. Frontend (terminal 2)
cd CodeNova-frontend\frontend
python -m http.server 5500
Open http://localhost:5500

## 3. Test
Register a farmer -> Apply -> Report claim -> Login as admin / admin123 to approve.
